<?php
    $msg = "";  
    use PHPMailer\PHPMailer\PHPMailer;

    if(isset($_POST['submit'])){
        $con = new mysqli('localhost', 'root', '', 'decosys');

		$name = $con->real_escape_string($_POST['uname']);
        $email = $con->real_escape_string($_POST['email']);
        $contact = $con->real_escape_string($_POST['contact']);
		$address = $con->real_escape_string($_POST['address']);
		$password = $con->real_escape_string($_POST['password']);
        $cPassword = $con->real_escape_string($_POST['cpassword']);
        
    if ($name == "" || $email == "" || $password != $cPassword)
    $msg = "Please check your inputs!";
    else {
        $sql = $con->query("SELECT id FROM signup WHERE email='$email'");
        if ($sql->num_rows > 0) {
            $msg = "Email already exists in the database!";
        }else {
            $token = 'qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM0123456789!$/()*';
            $token = str_shuffle($token);
            $token = substr($token, 0, 10);

            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            $con->query("INSERT INTO signup ( `name`, `contact`, `email`, `password`, `isEmailConfirmed`, `token`, `address`)
                VALUES ('$name','$contact', '$email', '$hashedPassword', '0', '$token','$address');
            ");

            include_once "PHPMailer/PHPMailer.php";
            include_once 'PHPMailer/SMTP.php';

            $mail = new PHPMailer();
            	//Server settings
				// $mail->SMTPDebug = 2;                                 // Enable verbose debug output
				$mail->isSMTP();                                      // Set mailer to use SMTP
				$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
				$mail->SMTPAuth = true;                               // Enable SMTP authentication
				$mail->Username = 'your mail id';                 // SMTP username
				$mail->Password = 'your mail password';                           // SMTP password
				$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
				$mail->Port = 465;      
				
				// users mailing code
            $mail->setFrom('your mail', 'usrname');
            $mail->addAddress($email, $name);
            $mail->Subject = "Please verify email!";
            $mail->isHTML(true);
            $mail->Body = "
                Please click on the link below:<br><br>
                
                <a class='button' href='https://buzz09.com/PHPEmailConfirmation/confirm.php?email=$email&token=$token'>Click Here</a>
            ";

            if ($mail->send())
                $msg = "You have been registered! Please verify your email!";
            else
                $msg = "Something wrong happened! Please try again!";
        }
    }

    }
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="css/main.css" rel="stylesheet">
    <title>Decosys</title>
</head>
<body>
<div class="header">
        <h1><img src="img/decosys_white.png" width="240"></h1>
        <h2>The Digital Eco-System</h2>
    </div>
    <div class="btn-left"><a href="index.php"><img src="img/buzz09.png" height="100"></a></div>
    <h1 class="msg"><?php if ($msg != "") echo $msg ; ?></h1>
   <div class="card-form">
  <form class="signup" action="signup.php" method="post">
    <div class="form-title">Sign Up First!
</div>
    <div class="form-body">
    <div class="row">
        <input type="text" name="uname" placeholder="Your Name*" required>
    </div>
    <div class="row">
        <input type="text" name="contact" placeholder="Phone Number*" required>
    </div>
    <div class="row">
        <input type="text" name="email" placeholder="Email Address*" required>
    </div>
    <div class="row">
        <input type="password" name="password" placeholder="Password*" required>
        <input type="password" name="cpassword" placeholder="Confirm Password*" required>
    </div>   
    <div class="row">
        <input type="text" name="address" placeholder="Postal Address" required>
    </div>
    </div>
    <div class="rule"></div>
    <div class="form-footer">
      <button type="submit" name="submit">Sign Me Up!<span class="fa fa-thumbs-o-up"></button>
      <button><a href="index.php"> Not Now!<span class="fa fa-ban"></span></a></button>
    </div>
  </form>
</div>
    
<script src="js/jquery.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
