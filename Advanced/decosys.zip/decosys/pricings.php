<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="css/main.css" rel="stylesheet">
    <title>Decosys</title>
</head>
<body>
<div class="header">
        <h1><img src="img/decosys_white.png" width="240"></h1>
        <h2>The Digital Eco-System</h2>
    </div>
    <div class="btn-left"><a href="index.php"><img src="img/buzz09.png" height="100"></a></div>
<!-- <div class="btn btn-right"><a href="index.html">Log Out</a></div> -->

    <div class="head_text"><h2>PreSet Packages</h2></div>


    <div class="container group">
      
      <div class="grid-1-5">
        <h2>Package 1</h2>
        <h3><sup>₹</sup>12,500<span class="small">/mo <br>Annual Commitment</span></h3>
        <ul>
          <li>3 Page Website</li>
          <li>1 Mobile App with option of a Cart</li>
          <li>62 Posts/ year (Facebook + Instagram)</li>
        </ul>	
        <a href="" class="button">Sign Up</a>		
      </div>
      <div class="grid-1-5">
        <h2>Package 2</h2>
        <h3><sup>₹</sup>22,917<span class="small">/mo <br>Annual Commitment</span></h3>
        
        <ul>
          <li>5 Page Website</li>
          <li>1 Mobile App with option of a Cart</li>
          <li>104 Posts/ year (Facebook + Instagram + LinkedIn)</li>
          <li>Online Advertisement Worth ₹17,000</li>
        </ul>	
        <a href="" class="button">Sign Up</a>		
      </div>
      <div class="grid-1-5">
        <h2>Package 3</h2>
        <h3><sup>₹</sup>26,250<span class="small">/mo <br>Annual Commitment</span></h3>
        <ul>
        <li>10 Page Website</li>
          <li>1 Mobile App with option of a Cart</li>
          <li>104 Posts/ year (Facebook + Instagram + LinkedIn + Pinterest)</li>
          <li>Online Advertisement Worth ₹24,000</li>
          <li> +36 Blogs/ year </li>
        </ul>
        <a href="" class="button">Sign Up</a>
      </div>		
    </div>
<script src="js/jquery.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>