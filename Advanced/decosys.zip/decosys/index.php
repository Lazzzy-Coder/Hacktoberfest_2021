<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="css/main.css" rel="stylesheet">
    <title>Decosys</title>
</head>
<body>
    <div class="header">
        <h1><img src="img/decosys_white.png" width="240"></h1>
        <h2>The Digital Eco-System</h2>
    </div>
    <div class="btn-left"><a href="index.php"><img src="img/buzz09.png" height="100"></a></div>
    <!-- <div class="btn btn-right"><a href="index.html">Log Out</a></div> -->

<!--<div class="main-container">
        <div class="adding_cart">
            <div class="cart">asdndsajknsdsnsdk</div>
            <div class="cart_btn"><a href="add.html">Add to cart</a></div>
        </div>
        <div class="menus">
            <div class="col-4"></div>
            <div class="col-4"></div>
            <div class="col-4"></div>
        </div>
    </div> -->
    <div class="db">
        <a href="pricings.php">
            <div class="db_colum1">
                <h2>Preset Packages</h2>
            </div>
        </a>
        <a href="custom.php">
            <div class="db_colum2">
                <h2>Customize Your Own</h2>
            </div>
        </a>
    </div>

<script src="js/jquery.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
