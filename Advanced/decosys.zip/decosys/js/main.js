$(".container").hover(function(){
    $(".container").removeClass("active");
    $(this).addClass("active");
  });
  
